const readline = require('readline');

const players = [
  {
    NOME: "Mario",
    VELOCIDADE: 4,
    MANOBRABILIDADE: 3,
    PODER: 3,
    PONTOS: 0,
  },
  {
    NOME: "Luigi",
    VELOCIDADE: 3,
    MANOBRABILIDADE: 4,
    PODER: 4,
    PONTOS: 0,
  },
  {
    NOME: "Peach",
    VELOCIDADE: 3,
    MANOBRABILIDADE: 4,
    PODER: 2,
    PONTOS: 0,
  },
  {
    NOME: "Bowser",
    VELOCIDADE: 5,
    MANOBRABILIDADE: 2,
    PODER: 5,
    PONTOS: 0,
  },
  {
    NOME: "Donkey Kong",
    VELOCIDADE: 4,
    MANOBRABILIDADE: 3,
    PODER: 3,
    PONTOS: 0,
  },
  {
    NOME: "Yoshi",
    VELOCIDADE: 2,
    MANOBRABILIDADE: 4,
    PODER: 3,
    PONTOS: 0,
  }
];

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

async function rollDice() {
  return Math.floor(Math.random() * 6) + 1;
}

async function getRandomBlock() {
  let random = Math.random();
  let result;

  switch (true) {
    case random < 0.33:
      result = "RETA";
      break;
    case random < 0.66:
      result = "CURVA";
      break;
    default:
      result = "CONFRONTO";
  }

  return result;
}

async function logRollResult(characterName, block, diceResult, attribute) {
  console.log(
    `${characterName} 🎲 rolou um dado de ${block} ${diceResult} + ${attribute} = ${
      diceResult + attribute
    }`
  );
}

async function playRaceEngine(playersInRace) {
  for (let round = 1; round <= 5; round++) {
    console.log(`🏁 Rodada ${round}`);

    // Sortear blocos para cada jogador
    let blocks = await Promise.all(playersInRace.map(() => getRandomBlock()));
    console.log(`Blocos: ${blocks.join(", ")}`);

    // Rolar dados para todos os jogadores
    let diceResults = await Promise.all(playersInRace.map(() => rollDice()));

    // Teste de habilidade e confronto
    let totalTestSkills = [];
    let powerResults = [];

    for (let i = 0; i < playersInRace.length; i++) {
      let totalTestSkill = 0;
      let player = playersInRace[i];
      let diceResult = diceResults[i];
      let block = blocks[i];

      if (block === "RETA") {
        totalTestSkill = diceResult + player.VELOCIDADE;
        await logRollResult(player.NOME, "velocidade", diceResult, player.VELOCIDADE);
      } else if (block === "CURVA") {
        totalTestSkill = diceResult + player.MANOBRABILIDADE;
        await logRollResult(player.NOME, "manobrabilidade", diceResult, player.MANOBRABILIDADE);
      } else if (block === "CONFRONTO") {
        let opponent = playersInRace[(i + 1) % playersInRace.length]; // Confronto com o próximo jogador
        let powerResult = diceResult + player.PODER;
        let opponentPowerResult = diceResults[(i + 1) % playersInRace.length] + opponent.PODER;
        powerResults.push({ player, opponent, powerResult, opponentPowerResult });

        console.log(`${player.NOME} confrontou com ${opponent.NOME}! 🥊`);
        await logRollResult(player.NOME, "poder", diceResult, player.PODER);
        await logRollResult(opponent.NOME, "poder", diceResults[(i + 1) % playersInRace.length], opponent.PODER);
      }
      totalTestSkills.push(totalTestSkill);
    }

    // Resolver confrontos
    powerResults.forEach(({ player, opponent, powerResult, opponentPowerResult }) => {
      if (powerResult > opponentPowerResult) {
        console.log(`${player.NOME} venceu o confronto! ${opponent.NOME} perdeu 1 ponto 🐢`);
        opponent.PONTOS--;
      } else if (opponentPowerResult > powerResult) {
        console.log(`${opponent.NOME} venceu o confronto! ${player.NOME} perdeu 1 ponto 🐢`);
        player.PONTOS--;
      } else {
        console.log("Confronto empatado! Nenhum ponto foi perdido.");
      }
    });

    // Verificar quem marcou pontos nas habilidades
    playersInRace.forEach((player, i) => {
      let block = blocks[i];
      if (block !== "CONFRONTO") {
        if (totalTestSkills[i] > totalTestSkills[(i + 1) % playersInRace.length]) {
          console.log(`${player.NOME} marcou um ponto!`);
          player.PONTOS++;
        }
      }
    });

    console.log("-----------------------------");
  }
}

async function declareWinner() {
  console.log("Resultado final:");
  players.forEach(player => {
    console.log(`${player.NOME}: ${player.PONTOS} ponto(s)`);
  });

  let winner = players.reduce((prev, current) => (prev.PONTOS > current.PONTOS ? prev : current));

  if (players.filter(player => player.PONTOS === winner.PONTOS).length > 1) {
    console.log("A corrida terminou em empate!");
  } else {
    console.log(`\n${winner.NOME} venceu a corrida! Parabéns! 🏆`);
  }
}

async function selectPlayers() {
  return new Promise((resolve) => {
    rl.question('Deseja liberar todos os jogadores para a corrida? (sim/não): ', (answer) => {
      let selectedPlayers = [];
      
      if (answer.toLowerCase() === 'sim') {
        selectedPlayers = players;
        console.log("Todos os jogadores foram liberados para a corrida.");
        resolve(selectedPlayers);
      } else {
        rl.question('Escolha o primeiro jogador (Mario, Luigi, Peach, Bowser, Donkey Kong, Yoshi): ', (player1) => {
          rl.question('Escolha o segundo jogador (Mario, Luigi, Peach, Bowser, Donkey Kong, Yoshi): ', (player2) => {
            selectedPlayers = [
              players.find(p => p.NOME.toLowerCase() === player1.toLowerCase()),
              players.find(p => p.NOME.toLowerCase() === player2.toLowerCase())
            ];
            resolve(selectedPlayers);
          });
        });
      }
    });
  });
}

async function startRace(selectedPlayers) {
  console.log(
    `🏁🚨 Corrida entre ${selectedPlayers.map(player => player.NOME).join(" e ")} começando...\n`
  );

  await playRaceEngine(selectedPlayers);
  await declareWinner();
}

async function main() {
  const selectedPlayers = await selectPlayers();
  await startRace(selectedPlayers);
  rl.close();
}

main();
